package com;

public class BankAppServices {
	public void bank() {
		System.out.println(" Bank Opening Time: 10.00 AM \n " + "Bank Closing Time: 6.00 PM \n"
				+ " Lunch Hour: 1.00 PM - 2.00 PM\n" + "Weekend Holidays- Saturday, Sunday\n"
				+ "Our Services: Bank_Balance_Check, Money_Deposite ,Money_Withdraw , Money_Transfer \n\n");
	}
}
