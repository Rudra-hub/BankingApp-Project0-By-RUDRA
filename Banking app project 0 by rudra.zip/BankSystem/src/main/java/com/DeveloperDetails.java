package com;

public class DeveloperDetails {
	public void devop() {
		System.out.println("HEY I AM RUDRA\nThis App is Under Development\n\n");
	}
}
