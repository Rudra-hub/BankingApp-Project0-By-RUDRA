package com;

//App.Java
public class App {

	public static void main( String[] args )
    {
        BankApp bankApp = new BankApp() ;
        bankApp.startBankingApp();
    }
}
